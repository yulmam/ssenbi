-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: ssenbi-rds-mysql.cfmuckwc4t6p.ap-northeast-2.rds.amazonaws.com    Database: ssenbidb
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `business` varchar(255) NOT NULL,
  `business_phone_number` varchar(255) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `is_deleted` bit(1) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `personal_phone_number` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  `customer_count` int NOT NULL,
  `message_count` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'string','string','2024-11-01 04:40:25.073648',_binary '\0','test','string','$2a$10$vk6aqDnZxPkvVTodS3P7rOl84F1cYINBPZgaPCyiZOh7.yTrt3cmy','string','2024-11-18 04:21:22.396664',_binary '	�a�Dښ})��	',5,4),(2,'김싸피가게','010-2222-2222','2024-11-01 08:11:10.538911',_binary '\0','ssenbi1','김싸피','$2a$10$5R9wSS1bKD8FzRXlPr2zH.auiJAcplPozXqItQmHZAeIaz8m9CIPC','010-1111-1111','2024-11-01 08:11:10.538932',_binary 'T���]\�H��Ów���\�',0,0),(3,'김싸피가네','010-2222-2222','2024-11-01 08:12:47.486115',_binary '\0','ssenbi2','김싸피','$2a$10$F/jD6gFY/t9BICl7Gzcj6un/PWi0ora10G7OU0xRAoH9rcMOCX1ca','010-1111-1111','2024-11-01 08:12:47.486135',_binary 'j���/D͘j\�\�\�\�e\�',0,0),(4,'bu','01012345678','2024-11-04 00:29:59.110214',_binary '\0','taehyeon','lth','$2a$10$GfQWQ5wo2wH/cVL6C0ewz.Bbo722ODfSqz0ZOkbJgMS2u2ah/OzOu','01012345678','2024-11-04 00:29:59.110259',_binary '�\�7$H �\��N�',0,0),(5,'김싸피4','010-2222-2222','2024-11-04 01:44:34.877808',_binary '\0','ssafy123','김싸피4','$2a$10$7xzJex3Kq9AWtB/yEbYXYOPv8smaKj977TzFMLrPeQ6XKFis9XMfa','010-1111-1111','2024-11-04 01:44:34.877872',_binary 'dF�Q,K@%����\�\�2u',0,0),(6,'qqqq','01010101010','2024-11-04 01:59:24.074677',_binary '\0','qqqq','qqqq','$2a$10$EH3LwkVUh/Bxf9zOBiAsT.TZbInIQJ73ddC9mUo6MMPXwJc4a6rle','01001010101','2024-11-19 00:53:17.410446',_binary '��/9}\�J3�P�&�*�',4,2),(7,'osaidvh','01012121211','2024-11-04 02:58:10.921119',_binary '\0','wowow','adslkfj','$2a$10$P6zBz/RQIFlGJr/EpFlos.y7qQuVGVgV5c99QjJ28DboNEtJoO0nq','01012121212','2024-11-04 02:58:10.921164',_binary '�B\�\"�F3����\r�#',0,0),(8,'김김김','010-111-1111','2024-11-04 03:00:02.063538',_binary '\0','ssafy8','김김김','$2a$10$usp95vdPfGmDo1Lgc6hHc.UDYFnKpGSwpm4ZrRJamef9i97eYgLBy','010-1111-1111','2024-11-04 03:00:02.063582',_binary 'fU?���J���\'�\�S(',0,0),(9,'ssenbi','01022222222','2024-11-04 04:39:15.040965',_binary '\0','ssenbi','ssenbi','$2a$10$m4Indcj3mtaCoGbIks/uRO7d.wzTiCl88n.R/xV63dNeQbXrJwzHS','01000000000','2024-11-04 04:39:15.041000',_binary '�L\0\�WnAް�\�\�*d8',0,0),(10,'ssenbi','01011111111','2024-11-04 04:51:09.944364',_binary '\0','ssenbi123','ssenbi','$2a$10$HX9f6FIX1/rCb6Wbf9J9Gead391SYqpFOKh4N2HQb73WgR8DvnUkW','01000000001','2024-11-18 07:51:10.220769',_binary 'hxK\�M�G��	�A�i',3,14),(11,'string','string','2024-11-04 05:06:46.827661',_binary '\0','test123','string','$2a$10$WxvUDkloY4L.mJoAfY5ADOU.yL4IJYVnv7R4VjFWlrogs6R5wJxOG','string','2024-11-04 05:06:46.827702',_binary '\�\�PB�\�H趴\n\��@',0,0),(12,'string','string','2024-11-04 05:18:23.626617',_binary '\0','test1','string','$2a$10$j2P7z4HEjUtAtFqW3RvPQeYgwFncV4xFtu6891ZzMoGFzMjZZduvm','string','2024-11-04 05:18:23.626629',_binary '\�\�6Lg�\�\�\�aUU',0,0),(13,'string','string','2024-11-04 07:25:49.229641',_binary '\0','string','string','$2a$10$j2XApuPMTbJOpqmNzNkyWukHdDpYzqbM5nGOYCrZgb4/ZGXV6MWmy','string','2024-11-04 07:25:49.229684',_binary '\n�5�MO��\�cO:\�V',0,0),(14,'bbb','bbb','2024-11-04 07:26:32.737340',_binary '\0','bbb','bbb','$2a$10$u/U62zn1FL9FbUQ1mfiqTeMA8zgHdvlne6dWF0qWFp48WyLZ19pfC','bbb','2024-11-04 07:26:32.737361',_binary '\�j��]@!��;1',0,0),(15,'ddd','ddd','2024-11-04 21:59:27.953290',_binary '\0','ddd','ddd','$2a$10$y8garhKnQzAatACe.7b6X.dbkwBjuBsSboyZ0Mn0qVldmNxxMsmWi','ddd','2024-11-04 21:59:27.953350',_binary 'C\�[/[\�E蝹Á��#�',0,0),(16,'테스트','010-2222-222','2024-11-05 00:53:55.365788',_binary '\0','testnew1','테스트','$2a$10$aktgymiMclaLQHx1bOAdk.0EX5aTzw1QhgmVmj6j5MHqxJh/aJULu','010-1111-1111','2024-11-15 04:30:50.697809',_binary '\�4mn$\'N4��y�P�lm',9,1),(17,'qwer','qwer','2024-11-05 01:00:30.238914',_binary '\0','aaa','aaa','$2a$10$9IvKkocHzgPT8qbjzmd9Ken/.ulrhYIdSazV4s9R2Qwn0/MCMSP.C','qwer','2024-11-05 01:07:49.196090',_binary 't�z��Bg��\�.RX�6',0,0),(18,'newnew23','010-2222-2223','2024-11-05 02:02:06.257796',_binary '\0','newnew2','newnew2','$2a$10$7JmqAcFEYJwQTCO8T7o1O.OFntZQOvLVX912ML2Ypgq9lrUQ5Jr5y','010-1111-1112','2024-11-05 03:31:46.198064',_binary '\�x�\�o�F\0�5+���\��',0,0),(19,'newnew2','010-2222-2222','2024-11-05 02:03:17.209529',_binary '\0','newnew1','newnew2','$2a$10$VUsedBh5ick0dAaIxj3vIuEst69RzZoujyjkmbyQpboo9C..2SSQG','010-1111-1111','2024-11-11 12:43:04.079339',_binary '\�Z6�RDw���\�ª,',2,0),(20,'string','string','2024-11-05 04:07:59.638133',_binary '\0','strin421421421421421321321412412421g','cOZs0d6GS0ebvP','$2a$10$a015uHGN1yb2tu0S4wx/Xesy2ooTImdunR9siaN6p5awdr/3JAsnO','string','2024-11-05 04:07:59.638133',_binary '��\���CJ���@v3�',0,0),(21,'string','string','2024-11-05 04:08:27.823981',_binary '\0','longtest','cOZs0d6GS0ebvP','$2a$10$gve0Xdg4R.QcZ6XwzwJX5eHHWENRNm1hsOFHN3e12TphYHLsrzVI.','string','2024-11-05 04:08:27.823981',_binary '�\�Ƌ\�@@��ş� B',0,0),(22,'string','string','2024-11-05 04:10:59.162748',_binary '\0','itslongtestnotinclude','Ekx3W32NnyZyS7JJfR4353534321412343215321','$2a$10$zQWEakfyu1cx9kaj8JptmOSQGj5Iihebl277bU0n1ZVbxsRMquugu','string','2024-11-05 04:10:59.162780',_binary '\�l6�_EF�H=�}�r�',0,0),(23,'string','906938619816','2024-11-05 04:52:55.846299',_binary '\0','gTUbHW52amxAqA','778248','$2a$10$LusHvr3G0.g4UW/1uJUqw.ojcgqvR3OADrq05cCVBLmCJYGEilFEC','58332365185','2024-11-05 04:52:55.846299',_binary 'N�X�:)N\����b��9',0,0),(24,'string','277190546018','2024-11-05 04:53:43.955065',_binary '\0','gt4tRo1lJOW3HRE','23442afweqwrgfqwerqw','$2a$10$n7YEbdKhSKolC1TRX/R/UO79l/eSyRafxonhbIawKvg7FgxzNsx2a','73545023575','2024-11-05 04:53:43.955078',_binary '3$+i-B��-lk\�B�',0,0),(25,'string','277190546018','2024-11-05 04:53:53.446832',_binary '\0','gt4tRo1lJOW3HR22222222222222222222222222222222222222222E','23442afweqwrgfqwerqw','$2a$10$h3sJ2WQh01hFxCZiTIbeoOaxtLqXpblsKWSnGZWBKjghWrTYddwX2','73545023575','2024-11-05 04:53:53.446845',_binary ';^>��M\���x\�\��_',0,0),(26,'string','979849477272','2024-11-05 04:54:20.719972',_binary '\0','E5ZxlY0Q2fWQkt8','9188559','$2a$10$nBM7HsAdpe/7FsfjyQPIzu7EnFinws8dD1.Ah.jDorNkoytxuYH2e','91309549673','2024-11-05 04:54:20.719972',_binary '0�؞��C��}A�KOY\�',0,0),(27,'aaa','010112345678','2024-11-05 08:26:35.874497',_binary '\0','aaaa1234','홍길동','$2a$10$4CtKf8EuJjT6EbusBsYWSeEq38gBe5WSsEyCRbQ1fOLoowHsOdCV6','01012345678','2024-11-05 08:26:35.874536',_binary '��o�^M ������\�',0,0),(28,'string','723928142700','2024-11-06 00:55:58.979115',_binary '\0','han12345','하너리','$2a$10$jFUMVOjtJUUkREHrKcPlpeMUFGY27ZpY/311oe1S6Hn/w.F52l716','07082549034','2024-11-06 00:55:58.979151',_binary '*��Ͷ	K1��\�0�I?',0,0),(29,'string','723928142700','2024-11-06 00:56:22.172899',_binary '\0','han123','하너리','$2a$10$dE6735u8FKNY5Pwgn9fV7u/w8deyeVvl6lgJ5uZ7XcOKVycDKm/jq','07082549034','2024-11-06 00:56:22.172921',_binary '\r���J���;���ӱ',0,0),(30,'string','12345678901','2024-11-07 04:45:52.152042',_binary '\0','test12345','하너리','$2a$10$XzmomKxufyYeVvTiNvevge07/9H4vQh93xKlbc5Jt8sKud6TNa5om','12345678901','2024-11-07 04:45:52.152042',_binary '1\�\�~�K׽�\r+:,k',0,0),(31,'asfd','11111111111','2024-11-12 07:09:49.654626',_binary '\0','asdasdf','아이우','$2a$10$65c3cnwKyIqfNsXnt/wuTeEc/D8oqck/V8Y/et0XYnDodg9vjxXSe','11111111111','2024-11-12 07:09:49.654667',_binary '\r\�{�B@��\�;g[�K',0,0),(32,'테스트','12345678','2024-11-13 03:57:41.495785',_binary '\0','testtest1','테스트','$2a$10$vd4NbTT.3JNiM6499hoDouMbL4NzMdEhNHwV42FVWav.2c6Q3EI7S','12345678','2024-11-18 06:18:36.152633',_binary 'y��=B,�у${�\�7',1,1),(33,'테스트테스트','01022222222','2024-11-15 03:05:18.381424',_binary '\0','testnew21','테스트','$2a$10$lQbUEmlNjJegYNnl5H6i7e2poFhaOfpDA/kouxw0hB1FJlF22vNIu','01011111111','2024-11-15 03:05:18.381452',_binary '�i�\��EԈ�\�Y\\=!',0,0),(34,'KMJ','020000000','2024-11-15 07:00:22.416334',_binary '\0','kmj5252','김민준','$2a$10$9ozoDJv05WbfXll35Z5YWuqO5ib1mVdFc85tcAcwSGrJ1gzMnzmY6','01000000000','2024-11-15 07:00:22.416342',_binary 'U\�ô?\�Da�{�c+��',0,0),(35,'KMJ','020000000','2024-11-15 07:00:22.411548',_binary '\0','kmj5252','김민준','$2a$10$R3IA6zmepLwDxlBc2tkOnezyDSU1ZePO.8lSgnYv4TXTjWveDvLNG','01000000000','2024-11-15 07:00:22.411578',_binary 'z.���\�N�*��H�;\�',0,0),(36,'KMJ','020000000','2024-11-15 07:00:22.411548',_binary '\0','kmj5252','김민준','$2a$10$Gar.v1wpyAAtUFuT6Fk70uh3gU6fBw4RBWJYKuaY7a4w5Abdk6bHm','01000000000','2024-11-15 07:00:22.411578',_binary '��L\��Jc����q\�',0,0),(37,'KMJ','020000000','2024-11-15 07:00:22.428900',_binary '\0','kmj5252','김민준','$2a$10$xkNRh9eLrmTUC7ELRWs8qu4gY4hZQjhKC1yutlfs6mWQpk6EU0zZm','01000000000','2024-11-15 07:00:22.428907',_binary '&���uK+�|Avq���',0,0),(38,'오오','01234567','2024-11-15 07:00:52.901473',_binary '\0','yulmam12345','김한얼','$2a$10$gQE98tAG4dUkhGLN..N4Qu.HebWXD7lXSBMwA5kUd3UKRxsphn.uq','01234567','2024-11-15 07:00:52.901483',_binary 'j\�\��|JT�#���kr',0,0),(39,'김한얼','010123456','2024-11-15 08:11:20.509179',_binary '\0','ssenbi12345','김한얼','$2a$10$I2ImTK/tg5z00dX2ZlfPsuDhz7WweLeUybZMeYRx2nra6K3lIXY8S','010123456','2024-11-15 08:11:20.509215',_binary 't\�ְD\�J4�\�\�T��',0,0),(40,'김','010123456','2024-11-15 08:12:56.173466',_binary '\0','ssenbi123456789','김한얼','$2a$10$QQ.EFTJu6dNCnwlEPLNVu.wc1R1EH/OibeYf3yZbXur/FUgrtM7D6','010123456','2024-11-15 08:12:56.173480',_binary '�dZ\�9F����\�\�e\�',0,0),(41,'착한낙지','1234567','2024-11-15 08:14:14.736903',_binary '\0','abcdefg','김낙지','$2a$10$6.fcokj8JYmkmzbk4pMGROHMnJPR/C6k8xI8YYY0U/IQAuA7gWySO','1234567','2024-11-15 08:14:14.736914',_binary '�=��U5I\�\��\�\nv',0,0),(42,'착한낙지','9876543','2024-11-15 08:14:54.261006',_binary '\0','zlfn94','김낙지','$2a$10$sMqSfoW2FTmH6a5rYGoIgO.VjULDKzybY2YZq8JczW7mVabyK6aQG','1234567','2024-11-15 08:21:19.048118',_binary '�M=\�\�D\�gםuTد',1,0),(43,'소마','0000000000','2024-11-15 08:22:50.771193',_binary '\0','i1004gy','이규열','$2a$10$P0nejbmLN8uz2qb2B6vnCuIPlowFEzDlsIU/nALFBQiH66PWYjecS','0000000000','2024-11-15 08:22:50.771204',_binary 'JU�\�\�\�Ep��\�\'���',0,0),(44,'오롤몇','103958672','2024-11-15 09:18:46.341072',_binary '\0','qwerqwer','황재하','$2a$10$shxE83OtJsWS5effOd0sSOl10IK6.6kec6DTfNCC5a4ZoaS/Or2wG','12345678','2024-11-15 09:22:22.972397',_binary '��x˨�O[�\�{�\�A�',2,0),(45,'최진혁의 상호','01041948357','2024-11-17 04:07:25.499124',_binary '\0','fun2314','최진혁','$2a$10$dGGqoswt9u1kfj/W79D1DujaH0k6SJy1TsPq538LMo9SNc/.XmqX.','01041948357','2024-11-17 04:16:34.253238',_binary '\�\�1�2\�M�$\�|\�i}',0,0),(46,'대웅제약','01038006891','2024-11-17 04:07:59.049401',_binary '\0','gotmfdk','이승주','$2a$10$quUtX5l1S6vaN.UVsm6uH.6PjukaG8XtygQ.kn4m28z6XB1YG2KQ2','01038006891','2024-11-17 04:08:32.633214',_binary 'mh�(oIS�v\�\�[\�ͭ',1,0),(47,'내상호','01000000000','2024-11-17 05:20:27.992313',_binary '\0','dstest','내이름','$2a$10$FdPuOwUg11L5E081Yt8Jqe/FWnVC.XhdWaMtSCQPz9ZFnk5Hm9RSi','01000000000','2024-11-17 05:20:27.992326',_binary '�=M�\�I0�L7d\�',0,0),(48,'사비','1012345675','2024-11-17 16:32:28.010746',_binary '\0','hello','반가워요','$2a$10$Yy6Zoc3lQNLAYLs1bsgC..4oV/nsY2JSuWJ4Npu1HXlOilaevOje2','01012345678','2024-11-17 16:36:35.106723',_binary '\�l9�p?B�1���',1,0),(49,'ssafy카페','01022222222','2024-11-18 07:52:39.364956',_binary '\0','ssafy1234','싸피','$2a$10$YskvDiV3Y9BEFG.ZY2PZseuMN/JXx.21LByuSsTqlc15EljamUyga','01011111111','2024-11-19 01:06:41.131170',_binary '��@\�\�O���;\�\�Eg',6,15);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 11:30:31
