-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: ssenbi-rds-mysql.cfmuckwc4t6p.ap-northeast-2.rds.amazonaws.com    Database: ssenbidb
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `color` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `tag_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4kwcvomqt30obfex433chwghj` (`member_id`),
  KEY `FK6sswx4al7ja71gxq0fuo4rhc0` (`tag_id`),
  CONSTRAINT `FK4kwcvomqt30obfex433chwghj` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK6sswx4al7ja71gxq0fuo4rhc0` FOREIGN KEY (`tag_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'RED','직장인',NULL,NULL),(2,'PINK','학생',NULL,NULL),(3,'SALMON','1반',NULL,NULL),(4,'ORANGE','2반',NULL,NULL),(5,'YELLOW','3반',NULL,NULL),(6,'GREEN','ssafy',NULL,NULL),(7,'RED','태그1',NULL,NULL),(8,'RED','태그1',NULL,NULL),(10,'RED','태그3',13,NULL),(11,'RED','앗살라말라이꿈',29,NULL),(12,'BLUE','싸피',29,NULL),(13,'GRAY','hello',6,NULL),(14,'PURPLE','zxcv',6,NULL),(17,'LIME','erfg',6,NULL),(20,'GRAY','gnngnf',6,NULL),(21,'ORANGE','test',10,NULL),(22,'PINK','aa123',10,NULL),(23,'RED','aa',10,NULL),(29,'LIME','태그2',19,NULL),(32,'BLUE','20대',16,NULL),(33,'GREEN','dsfsdf',6,NULL),(34,'ORANGE','na',6,NULL),(35,'ORANGE','aaaa',10,NULL),(36,'SALMON','aa4',10,NULL),(37,'ORANGE','새로운것만',10,NULL),(38,'PINK','30대',16,NULL),(40,'GRAY','단골',16,NULL),(42,'LIME','싸피',10,NULL),(43,'ORANGE','#test',10,NULL),(44,'YELLOW','ㄱㄱ',43,NULL),(45,'PURPLE','ㄱ',43,NULL),(46,'RED','ㄱㄱㄱ',43,NULL),(47,'RED','롤',43,NULL),(48,'RED','롤',43,NULL),(49,'GREEN','아',43,NULL),(50,'BEIGE','아',43,NULL),(51,'PURPLE','나',43,NULL),(52,'YELLOW','나',43,NULL),(53,'LIME','가',43,NULL),(54,'PURPLE','가',43,NULL),(55,'ORANGE','1234',10,NULL),(57,'RED','가자',43,NULL),(58,'GRAY','자',43,NULL),(59,'LIME','바',43,NULL),(60,'SKYBLUE','로',43,NULL),(61,'SKYBLUE','로',43,NULL),(62,'BEIGE','마',43,NULL),(63,'SKYBLUE','마',43,NULL),(64,'GRAY','사',43,NULL),(65,'GRAY','사',43,NULL),(66,'ORANGE','오',43,NULL),(67,'GRAY','오',43,NULL),(68,'LIME','라',43,NULL),(69,'ORANGE','오라',43,NULL),(71,'SALMON','바',10,NULL),(73,'RED','마',10,NULL),(74,'GREEN','아',10,NULL),(76,'PINK','어',10,NULL),(77,'BEIGE','여',10,NULL),(78,'YELLOW','오',10,NULL),(79,'SALMON','보',43,NULL),(80,'PURPLE','보',43,NULL),(81,'BEIGE','유',10,NULL),(82,'GRAY','조',43,NULL),(83,'ORANGE','이',10,NULL),(84,'BLUE','런',10,NULL),(85,'BLUE','시',10,NULL),(86,'GRAY','고',43,NULL),(87,'GREEN','고',43,NULL),(88,'PURPLE','카',43,NULL),(89,'PINK','카',43,NULL),(90,'YELLOW','차',43,NULL),(91,'GRAY','차',43,NULL),(92,'BEIGE','피',43,NULL),(93,'SKYBLUE','피',43,NULL),(94,'GRAY','ㅣ',43,NULL),(95,'PURPLE','ㅠㅣ',43,NULL),(96,'SKYBLUE','empty',6,NULL),(97,'BEIGE','김한얼',10,NULL),(98,'SKYBLUE','라랄',44,NULL),(99,'YELLOW','루루루루룰',44,NULL),(100,'ORANGE','홍길동',19,NULL),(101,'BLUE','홍길동2',19,NULL),(103,'PURPLE','초창기고객',1,NULL),(104,'RED','특수고객',1,NULL),(105,'YELLOW','남성',16,NULL),(106,'RED','여성',16,NULL),(107,'PINK','A109',32,NULL),(108,'YELLOW','싸피',32,NULL),(110,'BLUE','단골',49,NULL),(111,'ORANGE','20대 고객',49,NULL),(112,'ORANGE','50대 고객',49,NULL),(113,'RED','A109',49,NULL),(114,'ORANGE','가족고객',49,NULL);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 11:30:32
